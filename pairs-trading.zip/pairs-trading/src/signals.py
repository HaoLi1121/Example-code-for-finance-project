"""Z-score signals with entry, exit, and stop-loss bands."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .selection import Pair


def zscore(logp: pd.DataFrame, pair: Pair) -> pd.Series:
    """Spread z-score using formation-window parameters only (no re-estimation)."""
    spread = logp[pair.y] - pair.beta * logp[pair.x] - pair.alpha
    return (spread - pair.mu) / pair.sigma


def positions(z: pd.Series, entry: float = 1.5, exit: float = 0.0, stop: float = 2.5) -> pd.Series:
    """Target position on the spread, decided at each day's close.

    +1 = long spread (long y, short x), -1 = short spread.
    After a stop-loss, wait until |z| falls back inside the entry band before re-entering.
    The last day is forced flat so no position leaks past the trading window.
    """
    pos = np.zeros(len(z))
    state, locked = 0, False
    for t, zt in enumerate(z.to_numpy()):
        if np.isnan(zt):
            pos[t] = state
            continue
        if locked and abs(zt) < entry:
            locked = False
        if state == 0 and not locked:
            if zt > entry and zt < stop:
                state = -1
            elif zt < -entry and zt > -stop:
                state = 1
        elif state != 0:
            if abs(zt) >= stop:          # stop-loss
                state, locked = 0, True
            elif state * zt >= -exit:    # spread reverted
                state = 0
        pos[t] = state
    pos[-1] = 0
    return pd.Series(pos, index=z.index, name="position")
