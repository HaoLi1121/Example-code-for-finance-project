"""Performance metrics."""
from __future__ import annotations

import numpy as np
import pandas as pd


def max_drawdown(rets: pd.Series) -> float:
    equity = (1 + rets).cumprod()
    return (equity / equity.cummax() - 1).min()


def summary(rets: pd.Series, trades: pd.DataFrame | None = None, periods: int = 252) -> pd.Series:
    ann_ret = (1 + rets).prod() ** (periods / len(rets)) - 1
    ann_vol = rets.std(ddof=1) * np.sqrt(periods)
    out = {
        "annual_return": ann_ret,
        "annual_vol": ann_vol,
        "sharpe": rets.mean() / rets.std(ddof=1) * np.sqrt(periods) if ann_vol > 0 else np.nan,
        "max_drawdown": max_drawdown(rets),
        "pct_days_invested": (rets != 0).mean(),
    }
    if trades is not None and len(trades):
        out |= {
            "n_trades": len(trades),
            "win_rate": (trades["return"] > 0).mean(),
            "avg_trade_return": trades["return"].mean(),
            "avg_holding_days": trades["days"].mean(),
        }
    return pd.Series(out)


def by_year(rets: pd.Series) -> pd.DataFrame:
    g = rets.groupby(rets.index.year)
    return pd.DataFrame({
        "return": g.apply(lambda r: (1 + r).prod() - 1),
        "sharpe": g.apply(lambda r: r.mean() / r.std() * np.sqrt(252) if r.std() > 0 else np.nan),
        "max_drawdown": g.apply(max_drawdown),
    })
