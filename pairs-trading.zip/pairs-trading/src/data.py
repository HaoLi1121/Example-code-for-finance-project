"""Download and clean daily prices."""
from __future__ import annotations

import numpy as np
import pandas as pd


def download_prices(tickers: list[str], start: str, end: str) -> pd.DataFrame:
    """Adjusted close prices from Yahoo Finance (dates x tickers)."""
    import yfinance as yf

    raw = yf.download(tickers, start=start, end=end, auto_adjust=True, progress=False)
    prices = raw["Close"] if isinstance(raw.columns, pd.MultiIndex) else raw[["Close"]]
    if prices.shape[1] == 1 and len(tickers) == 1:
        prices.columns = tickers
    return prices.sort_index()


def clean_prices(prices: pd.DataFrame, max_missing: float = 0.05) -> pd.DataFrame:
    """Drop tickers with too many gaps, forward-fill short gaps, drop leading NaNs.

    Forward-filling only uses past values, so it does not introduce look-ahead.
    """
    keep = prices.columns[prices.isna().mean() <= max_missing]
    out = prices[keep].ffill(limit=5)
    return out.dropna(how="any")


def to_log(prices: pd.DataFrame) -> pd.DataFrame:
    return np.log(prices)
