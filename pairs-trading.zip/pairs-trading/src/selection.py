"""Pair selection on a formation window: correlation filter -> Engle-Granger -> half-life."""
from __future__ import annotations

from dataclasses import dataclass
import warnings
from itertools import combinations

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller, coint


@dataclass
class Pair:
    y: str
    x: str
    alpha: float       # intercept of log(y) on log(x)
    beta: float        # hedge ratio
    mu: float          # spread mean (formation window)
    sigma: float       # spread std (formation window)
    pvalue: float      # Engle-Granger p-value
    half_life: float   # mean-reversion half-life in days


def half_life(spread: pd.Series) -> float:
    """Half-life from an AR(1) on the spread: d(s_t) = c + phi * s_{t-1} + e."""
    lag = spread.shift(1).dropna()
    delta = spread.diff().dropna()
    phi = sm.OLS(delta, sm.add_constant(lag)).fit().params.iloc[1]
    return -np.log(2) / phi if phi < 0 else np.inf


def fit_pair(logp: pd.DataFrame, y: str, x: str) -> Pair:
    ols = sm.OLS(logp[y], sm.add_constant(logp[x])).fit()
    alpha, beta = ols.params.iloc[0], ols.params.iloc[1]
    spread = logp[y] - beta * logp[x] - alpha
    pval = coint(logp[y], logp[x], trend="c")[1]  # MacKinnon EG critical values
    return Pair(y, x, alpha, beta, spread.mean(), spread.std(ddof=1), pval, half_life(spread))


def select_pairs(
    logp: pd.DataFrame,
    min_corr: float = 0.8,
    max_pvalue: float = 0.05,
    half_life_bounds: tuple[float, float] = (1, 60),
    max_pairs: int = 10,
    adf_confirm: bool = True,
) -> list[Pair]:
    """Rank candidate pairs using ONLY data in `logp` (the formation window)."""
    corr = logp.corr()
    candidates = []
    for a, b in combinations(logp.columns, 2):
        if abs(corr.loc[a, b]) < min_corr:
            continue
        # Engle-Granger is not symmetric: try both orientations, keep the stronger one.
        best = min((fit_pair(logp, a, b), fit_pair(logp, b, a)), key=lambda p: p.pvalue)
        if best.pvalue > max_pvalue or best.beta <= 0:
            continue
        if not half_life_bounds[0] <= best.half_life <= half_life_bounds[1]:
            continue
        if adf_confirm:
            spread = logp[best.y] - best.beta * logp[best.x] - best.alpha
            with warnings.catch_warnings():  # statsmodels return-type FutureWarning
                warnings.simplefilter("ignore", FutureWarning)
                adf_p = adfuller(spread, regression="c", autolag="AIC")[1]
            if adf_p > max_pvalue:
                continue
        candidates.append(best)

    candidates.sort(key=lambda p: p.pvalue)
    # Don't let one stock dominate the book: each ticker used at most once.
    chosen, used = [], set()
    for p in candidates:
        if p.y in used or p.x in used:
            continue
        chosen.append(p)
        used |= {p.y, p.x}
        if len(chosen) == max_pairs:
            break
    return chosen
