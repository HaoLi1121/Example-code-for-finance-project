"""Run the walk-forward pairs backtest.

Example:
    python run.py --start 2014-01-01 --end 2025-01-01 --cost-bps 10
    python run.py --synthetic            # offline sanity check
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.backtest import walk_forward
from src.data import clean_prices, download_prices
from src.metrics import by_year, summary

# Large U.S. healthcare names. NOTE: today's constituents -> survivorship bias (see README).
TICKERS = [
    "JNJ", "UNH", "PFE", "MRK", "ABBV", "LLY", "TMO", "ABT", "DHR", "BMY",
    "AMGN", "MDT", "CVS", "CI", "ELV", "HUM", "SYK", "BSX", "BDX", "ZBH",
    "BAX", "ISRG", "EW", "GILD", "VRTX", "REGN", "BIIB", "IQV", "STE", "TFX",
]


def synthetic_prices(n_days: int = 2000, n_noise: int = 8, phi: float = 0.85, seed: int = 0) -> pd.DataFrame:
    """Random walks plus three planted cointegrated pairs (OU spread with AR coefficient phi)."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2015-01-01", periods=n_days)
    cols = {}
    for k in range(3):
        x = np.cumsum(rng.normal(0, 0.015, n_days)) + 4
        s = np.zeros(n_days)
        for t in range(1, n_days):                      # phi=0.85 -> half-life ~4 days
            s[t] = phi * s[t - 1] + rng.normal(0, 0.01)
        cols[f"X{k}"], cols[f"Y{k}"] = x, 0.2 + 0.9 * x + s
    for k in range(n_noise):
        cols[f"N{k}"] = np.cumsum(rng.normal(0, 0.015, n_days)) + 4
    return np.exp(pd.DataFrame(cols, index=idx))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="2014-01-01")
    ap.add_argument("--end", default="2025-01-01")
    ap.add_argument("--cost-bps", type=float, default=10.0)
    ap.add_argument("--formation", type=int, default=252)
    ap.add_argument("--trading", type=int, default=126)
    ap.add_argument("--entry", type=float, default=1.5)
    ap.add_argument("--stop", type=float, default=2.5)
    ap.add_argument("--max-pairs", type=int, default=10)
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    prices = synthetic_prices() if args.synthetic else clean_prices(
        download_prices(TICKERS, args.start, args.end))
    print(f"{prices.shape[1]} tickers, {len(prices)} days")

    rets, trades = walk_forward(
        prices, formation_days=args.formation, trading_days=args.trading,
        cost_bps=args.cost_bps, entry=args.entry, stop=args.stop, max_pairs=args.max_pairs,
    )

    out = Path(args.out)
    out.mkdir(exist_ok=True)
    stats = summary(rets, trades)
    print("\n", stats.round(4).to_string(), "\n\n", by_year(rets).round(4).to_string())
    stats.to_csv(out / "summary.csv")
    trades.to_csv(out / "trades.csv", index=False)
    rets.to_csv(out / "daily_returns.csv")

    fig, ax = plt.subplots(figsize=(9, 4))
    (1 + rets).cumprod().plot(ax=ax, lw=1.2)
    ax.set(title=f"Walk-forward pairs strategy, net of {args.cost_bps:g} bps", ylabel="Growth of $1")
    fig.tight_layout()
    fig.savefig(out / "equity_curve.png", dpi=150)


if __name__ == "__main__":
    main()
