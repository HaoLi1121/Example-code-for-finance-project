import numpy as np
import pandas as pd

from run import synthetic_prices
from src.backtest import walk_forward
from src.selection import select_pairs
from src.signals import positions


def test_finds_planted_pairs():
    prices = synthetic_prices(n_days=600)
    pairs = select_pairs(np.log(prices.iloc[:252]))
    found = {frozenset((p.y, p.x)) for p in pairs}
    planted = {frozenset((f"X{k}", f"Y{k}")) for k in range(3)}
    assert planted <= found


def test_no_lookahead():
    """Scrambling prices after a cutoff must not change any return before it."""
    prices = synthetic_prices(n_days=1000)
    cut = prices.index[700]
    shocked = prices.copy()
    rng = np.random.default_rng(1)
    shocked.loc[shocked.index > cut] *= np.exp(rng.normal(0, 0.2, shocked.loc[shocked.index > cut].shape))

    r1, _ = walk_forward(prices)
    r2, _ = walk_forward(shocked)
    pd.testing.assert_series_equal(r1.loc[:cut], r2.loc[:cut])


def test_position_logic():
    z = pd.Series([0, 1.6, 1.0, -0.1, -1.7, -3.0, -2.0, -1.0, 0.5, 0.0])
    pos = positions(z, entry=1.5, exit=0.0, stop=2.5).tolist()
    # enter short, revert -> flat, enter long, stop out, locked until |z|<1.5, forced flat at end
    assert pos == [0, -1, -1, 0, 1, 0, 0, 0, 0, 0]
